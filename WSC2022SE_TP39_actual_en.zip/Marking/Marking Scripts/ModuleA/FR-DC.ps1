Write-Host "# === Sub Criterion: FR-DC.wsc2024.fr ===`r`n" -ForeGroundColor Green

Write-Host "# Aspect - ADDS: DC installed and configured" -ForeGroundColor Green
echo "Get-ADDomainController | select HostName,Enabled"
Get-ADDomainController | select HostName,Enabled | oh
pause

Write-Host "# Aspect - ADDS: Create users" -ForeGroundColor Green
echo "'Managers','Competitors','Visitors' | foreach { Get-ADUser -Filter * -SearchBase `"ou=`$_,dc=wsc2024,dc=fr`" | measure | select Count }"
'Managers','Competitors','Visitors' | foreach { Get-ADUser -Filter * -SearchBase "ou=$_,dc=wsc2024,dc=fr" | measure | select Count } | oh
pause

Write-Host "# Aspect - ADDS: Properties of the imported users" -ForeGroundColor Green
echo "Get-ADUser mgr-001 -Properties * | select City,Enabled,DisplayName,GivenName,mail,OfficePhone,Organization,Surname,Title"
Get-ADUser mgr-001 -Properties * | select City,Enabled,DisplayName,GivenName,mail,OfficePhone,Organization,Surname,Title | oh
pause

Write-Host "# Aspect - ADDS: Group membership of the imported users" -ForeGroundColor Green
echo "'FR_Managers','FR_Competitors','FR_Visitors' | foreach { Get-ADGroupMember -Identity `$_ | measure | select Count }"
'FR_Managers','FR_Competitors','FR_Visitors' | foreach { Get-ADGroupMember -Identity $_ | measure | select Count } | oh
pause

Write-Host "# Aspect - DNS: internal wsc2024.fr zone" -ForeGroundColor Green
echo "'FR-EDGE','FR-DC','FR-FILE','FR-SRV' | foreach { Resolve-DnsName -Type A `$_ | select Name,IPAddress }"
'FR-EDGE','FR-DC','FR-FILE','FR-SRV' | foreach { Resolve-DnsName -Type A $_ | select Name,IPAddress } | oh
pause

Write-Host "# Aspect - DNS: Forwarder" -ForeGroundColor Green
echo "Get-DnsServerForwarder | select IPAddress"
Get-DnsServerForwarder | select IPAddress | oh
pause

Write-Host "# Aspect - DNS: Root hint" -ForeGroundColor Green
echo "Get-DnsServerRootHint | findstr INET`r`n"
Get-DnsServerRootHint | findstr INET
echo ""
pause

Write-Host "# Aspect - GPO: Password policy" -ForeGroundColor Green
echo "Set-ADAccountPassword `$('com-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 55)) -OldPassword (ConvertTo-SecureString -AsPlainText -Force -String Skill39) -NewPassword (ConvertTo-SecureString -AsPlainText -Force -String skill39)"
Set-ADAccountPassword $('com-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 55)) -OldPassword (ConvertTo-SecureString -AsPlainText -Force -String Skill39) -NewPassword (ConvertTo-SecureString -AsPlainText -Force -String skill39)
echo ""
echo "Set-ADAccountPassword `$('mgr-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 26)) -OldPassword (ConvertTo-SecureString -AsPlainText -Force -String Skill39) -NewPassword (ConvertTo-SecureString -AsPlainText -Force -String skill39)"
Set-ADAccountPassword $('mgr-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 26)) -OldPassword (ConvertTo-SecureString -AsPlainText -Force -String Skill39) -NewPassword (ConvertTo-SecureString -AsPlainText -Force -String skill39)
pause

Write-Host "# Aspect - ADCS: CA installed and configured" -ForeGroundColor Green
echo "certutil -CAInfo | Select-String -Pattern 'CA name|CA type|CRL\[0\]'"
certutil -CAInfo | Select-String -Pattern 'CA name|CA type|CRL\[0\]' | oh
echo "certutil -TCAInfo | findstr Issuer`r`n"
certutil -TCAInfo | findstr Issuer
echo ""
pause

Write-Host "# Aspect - ADCS: CDP and AIA configured" -ForeGroundColor Green
echo "Get-CACrlDistributionPoint | where AddToCertificateCdp -EQ true | select Uri"
Get-CACrlDistributionPoint | where AddToCertificateCdp -EQ true | select Uri | oh
echo "Get-CAAuthorityInformationAccess | where AddToCertificateAia -EQ true |select Uri`r`n"
Get-CAAuthorityInformationAccess | where AddToCertificateAia -EQ true | select Uri | oh
echo ""
pause

Write-Host "# Aspect - ADCS: Templates" -ForeGroundColor Green
echo "Get-CATemplate | select Name | where Name -Like 'FR_*'"
Get-CATemplate | select Name | where Name -Like 'FR_*' | oh
pause

Write-Host "# Aspect - ADFS: FS configured" -ForeGroundColor Green
echo "Get-AdfsProperties | select *Name"
Get-AdfsProperties | select *Name | oh
pause
