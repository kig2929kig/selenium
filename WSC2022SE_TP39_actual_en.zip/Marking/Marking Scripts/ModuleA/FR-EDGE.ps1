Write-Host "# === Sub Criterion: FR-EDGE.wsc2024.fr ===`r`n" -ForeGroundColor Green

Write-Host "# Aspect - Domain member" -ForeGroundColor Green
echo "Get-ComputerInfo | select CsDomain"
Get-ComputerInfo | select CsDomain | oh
pause

Write-Host "# Aspect - Forwarding" -ForeGroundColor Green
echo "Get-RemoteAccess | select RoutingStatus"
Get-RemoteAccess | select RoutingStatus | oh
pause

Write-Host "# Aspect - Routing" -ForeGroundColor Green
echo "Get-NetRoute -AddressFamily IPv4 -Protocol NetMgmt | select DestinationPrefix,NextHop"
Get-NetRoute -AddressFamily IPv4 -Protocol NetMgmt | select DestinationPrefix,NextHop | oh
pause

Write-Host "# Aspect - NAT" -ForeGroundColor Green
echo "netsh routing ip nat show interface"
netsh routing ip nat show interface
pause

Write-Host "# Aspect - DHCP" -ForeGroundColor Green
echo "Get-DhcpServerv4Lease 172.16.1.0 | select IPAddress,HostName"
Get-DhcpServerv4Lease 172.16.1.0 | select IPAddress,HostName | oh
pause

Write-Host "# Aspect - Site-to-Site VPN" -ForeGroundColor Green
echo "Get-VpnS2SInterface | select Destination,ConnectionState,Protocol,AuthenticationMethod"
Get-VpnS2SInterface | select Destination,ConnectionState,Protocol,AuthenticationMethod | oh
pause
