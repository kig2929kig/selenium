Write-Host "# === Sub Criterion: FR-FILE.wsc2024.fr ===`r`n" -ForeGroundColor Green

Write-Host "# Aspect - ADDS: DC installed and configured" -ForeGroundColor Green
echo "Get-ADDomainController | select HostName,IsGlobalCatalog,Enabled"
Get-ADDomainController | select HostName,IsGlobalCatalog,Enabled | oh
pause

Write-Host "# Aspect - RAID5" -ForeGroundColor Green
echo "Set-Content -Path C:\diskpart.txt -Value @('list disk','list volume','exit')"
echo "diskpart /s c:\diskpart.txt"
Set-Content -Path C:\diskpart.txt -Value @('list disk','list volume','exit')
diskpart /s c:\diskpart.txt
pause