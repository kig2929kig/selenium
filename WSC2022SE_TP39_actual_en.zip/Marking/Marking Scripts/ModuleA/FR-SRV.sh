#!/bin/bash

echo -e '\e[32m === Sub Criterion: FR-SRV.wsc2024.fr === \e[m'
echo
read

echo -e '\e[32mAspect - Domain member\e[m'
echo 'Login: mgr-001'
echo 'Password: Skill39'
read
echo 'grep mgr-001 /etc/passwd'
grep mgr-001 /etc/passwd
echo
read

echo -e '\e[32mE-Mail: SSL/TLS\e[m'
echo '# openssl s_client -connect 127.0.0.1:465 | grep issuer'
echo quit | openssl s_client -connect 127.0.0.1:465 | grep issuer
echo

echo '# openssl s_client -connect 127.0.0.1:993 | grep issuer'
echo quit | openssl s_client -connect 127.0.0.1:993 | grep issuer
echo
read
