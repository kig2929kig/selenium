#!/bin/bash

echo -e '\e[32m === Sub Criterion: INET === \e[m'
echo
read

echo -e '\e[32mAspect - DNS: internet.com zone\e[m'
echo '# host INET.internet.com'
host INET.internet.com
echo

echo '# host -t mx internet.com'
host -t mx internet.com
echo
read

echo -e '\e[32mAspect - DNS: Microsft NCSI\e[m'
echo '# host dns.msftncsi.com'
host dns.msftncsi.com
echo

echo '# host www.msftconnecttest.com'
host www.msftconnecttest.com
echo
read

echo -e '\e[32mAspect - DNS: Forwarders\e[m'
echo '# named-checkconf -z | grep wsc'
named-checkconf -z | grep wsc
echo

echo '# host dmzsrv.wsc2022.kr'
host dmzsrv.wsc2022.kr
echo

echo '# host FR-EDGE.wsc2024.fr'
host FR-EDGE.wsc2024.fr
echo
read

echo -e '\e[32mAspect - CA: Root CA\e[m'
echo '# openssl x509 -in /etc/ssl/CA/cacert.pem -text -noout -subject'
openssl x509 -in /etc/ssl/CA/cacert.pem -text -noout -subject
echo
read

echo -e '\e[32mAspect - CA: CDP and AIA\e[m'
echo '# openssl x509 -in /etc/ssl/CA/cacert.pem -text -noout -ext crlDistributionPoints,authorityInfoAccess'
openssl x509 -in /etc/ssl/CA/cacert.pem -text -noout -ext crlDistributionPoints,authorityInfoAccess
echo
read

echo -e '\e[32mAspect - Web: Microsoft NCSI\e[m'
echo '# curl http://www.msftconnecttest.com/connecttest.txt'
curl http://www.msftconnecttest.com/connecttest.txt
echo '<- No Enter'
echo
echo
read

echo -e '\e[32mAspect - Web: www.internet.com site\e[m'
echo '# curl -I -k https://www.internet.com/ | grep HTTP'
curl -I -k https://www.internet.com/ | grep HTTP
echo
read
