#!/bin/bash

echo -e '\e[32m === Sub Criterion: KR-EDGE.wsc2022.kr === \e[m'
echo
read

echo -e '\e[32mAspect - Forwarding\e[m'
echo '# cat /proc/sys/net/ipv4/ip_forward'
cat /proc/sys/net/ipv4/ip_forward
echo
read

echo -e '\e[32mAspect - Routing\e[m'
echo '# ip route list match 210.103.5.64/26'
ip route list match 210.103.5.64/26
echo
echo '# ip route list match 210.103.5.128/25'
ip route list match 210.103.5.128/25
echo
read

echo -e '\e[32mAspect - nftables: NAT Rules\e[m'
echo '# nft list ruleset'
read
nft list ruleset | less
echo
read

echo -e '\e[32mAspect - SIte-to-Site VPN\e[m'
echo '# ipsec statusall'
ipsec statusall
echo
read
