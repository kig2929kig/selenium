Write-Host "# === Sub Criterion: REMOTE ===`r`n" -ForeGroundColor Green

Write-Host "# Aspect - E-Mail: Send & receive mail" -ForeGroundColor Green
echo "Send mail to mgr-001@wsc2024.fr`r`n"
pause

Write-Host "# Aspect - E-Mail: Secoundary mail server" -ForeGroundColor Green
echo "Stop postfix service on dmzsrv"
echo "Send mail to james@wsc2022.kr"
echo "On FR-SRV, mailq"
echo "Start postfix service on dmzsrv`r`n"
pause

Write-Host "# Aspect - WAP: Publish RDS" -ForeGroundColor Green
echo "Launch IE, then browse https://rds.wsc2024.fr/RDWeb/`r`n"
& 'C:\Program Files\internet explorer\iexplore.exe' https://rds.wsc2024.fr/RDWeb/
pause

Write-Host "# Aspect - RDS: app from the internet" -ForeGroundColor Green
echo "Launch WordPad RemoteApp via RD web`r`n"
pause

Write-Host "# Aspect - Remote Access VPN: Authentication" -ForeGroundColor Green
echo "Stop freeradius service on intsrv and start freeradius -X"
echo "Connect to VPN adapter `"WSC`" using username: james and password: Pa`$`$worD`r`n"
echo ""
pause

Write-Host "# Aspect - Remote Access VPN: Functional" -ForeGroundColor Green
echo "Get-VPNConnection WSC -AllUserConnection | select ServerAddress,TunnelType,ConnectionStatus"
Get-VPNConnection WSC -AllUserConnection | select ServerAddress,TunnelType,ConnectionStatus | oh
pause
echo "ping 192.168.1.1"
ping 192.168.1.1
echo "`r`nping 172.16.1.1"
ping 172.16.1.1
pause

Write-Host "# Aspect - Remote Access VPN: Address assignment" -ForeGroundColor Green
echo "ipconfig /all"
ipconfig /all
pause
