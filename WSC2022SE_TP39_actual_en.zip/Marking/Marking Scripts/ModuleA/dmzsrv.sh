#!/bin/bash

echo -e '\e[32m === Sub Criterion: dmzsrv.wsc2022.kr === \e[m'
echo
read

echo -e '\e[32mAspect - DNS: internal wsc2022.kr zone\e[m'
echo '# host kr-edge.wsc2022.kr'
host kr-edge.wsc2022.kr
echo

echo '# host fw.wsc2022.kr'
host fw.wsc2022.kr
echo

echo '# host intsrv.wsc2022.kr'
host intsrv.wsc2022.kr
echo

echo '# host dmzsrv.wsc2022.kr'
host dmzsrv.wsc2022.kr
echo

echo '# host -t mx wsc2022.kr'
host -t mx wsc2022.kr
echo
read

echo -e '\e[32mAspect - DNS: Reverse zone\e[m'
echo '# host 10.1.1.2'
host 10.1.1.2
echo

echo '# host 10.1.1.1'
host 10.1.1.1
echo

echo '# host 192.168.1.254'
host 192.168.1.254
echo

echo '# host 192.168.2.254'
host 192.168.2.254
echo

echo '# host 192.168.1.1'
host 192.168.1.1
echo

echo '# host 192.168.2.1'
host 192.168.2.1
echo
read

echo -e '\e[32mAspect - DNS: Forwarder\e[m'
echo '# named-checkconf -p | grep -A 2 forwarders'
named-checkconf -p | grep -A 2 forwarders
echo
read

echo -e '\e[32mAspect - DNS: Root hint\e[m'
echo '# grep INET /usr/share/dns/root.hints'
grep INET /usr/share/dns/root.hints
echo
read

echo -e '\e[32mAspect - Web: www.wsc2022.kr site\e[m'
echo '# curl -l -k https://www.wsc2022.kr | grep HTTP'
curl -I -k https://www.wsc2022.kr | grep HTTP
echo

echo '# openssl s_client -connect 127.0.0.1:443 | grep issuer'
echo '' | openssl s_client -connect 127.0.0.1:443 | grep issuer
echo
read

echo -e '\e[32mAspect - FTP\e[m'
echo '# echo assessment > assessment.html && curl -u james:Skill39 -T assessment.html ftp://127.0.0.1/ && curl -k https://www.wsc2022.kr/assessment.html'
echo assessment > assessment.html && curl -u james:Skill39 -T assessment.html ftp://127.0.0.1/ && curl -k https://www.wsc2022.kr/assessment.html
echo

