#!/bin/bash

echo -e '\e[32m === Sub Criterion: fw.wsc2022.kr === \e[m'
echo
read

echo -e '\e[32mAspect - nftables: Packet filtering\e[m'
echo '# nft list ruleset'
read
nft list ruleset | less
echo
echo '# less /etc/nftables.conf'
read
less /etc/nftables.conf
read

echo -e '\e[32mAspect - DHCP: DDNS\e[m'
echo '# tail -n 15 /var/lib/dhcp/dhcpd.leases | grep ddns-.*-name'
tail -n 15 /var/lib/dhcp/dhcpd.leases | grep ddns-.*-name
echo
read

