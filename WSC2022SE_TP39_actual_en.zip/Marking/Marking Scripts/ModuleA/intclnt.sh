#!/bin/bash

echo -e '\e[32m === Sub Criterion: intclnt.wsc2022.kr === \e[m'
echo
read

echo -e '\e[32mAspect - OpenLDAP: Login\e[m'
echo 'login: james'
echo 'Password: Pa$$worD'
read
echo 'grep james /etc/passwd'
grep james /etc/passwd
echo
read

echo -e '\e[32mAspect - E-Mail: Configured account\e[m'
echo 'Log in as "james" on GNOME session. Launch Thunderbird, then open account settings of james@wsc2022.kr'
thunderbird &
echo
read

echo -e '\e[32mAspect - E-Mail: Send & receive mail\e[m'
echo 'Send mail to user@internet.com'
echo
read

echo -e '\e[32mAspect - DHCP: Address assignment\e[m'
echo '# tail -n 15 /var/lib/dhcp/dhclient.leases | egrep "fixed|identifier"'
tail -n 15 /var/lib/dhcp/dhclient.leases | egrep 'fixed|identifier'
echo
read

echo -e '\e[32mAspect - Web: Without authentication\e[m'
echo '# curl -I http://intra.wsc2022.kr/wsc2022/ | grep HTTP'
curl -I http://intra.wsc2022.kr/wsc2022/ | grep HTTP
echo
read

echo -e '\e[32mAspect - Cacti: Login\e[m'
echo 'Username: admin'
echo 'Password: Skill39'
firefox http://monitor.wsc2022.kr/monitor &
echo
read

echo -e '\e[32mAspect - Cacti: Graphs\e[m'
echo 'Check graphs'
echo
read
