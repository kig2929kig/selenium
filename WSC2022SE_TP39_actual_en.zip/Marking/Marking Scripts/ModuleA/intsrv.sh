#!/bin/bash

echo -e '\e[32m === Sub Criterion: intsrv.wsc2022.kr === \e[m'
echo
read

echo -e '\e[32mAspect - OpenLDAP: User object\e[m'
echo "# ldapsearch -x -D 'cn=admin,dc=wsc2022,dc=kr' -w Skill39 -b 'dc=wsc2022,dc=kr' '(&(objectClass=posixAccount)(|(uid=james)(uid=donald)))" 
read
ldapsearch -x -D 'cn=admin,dc=wsc2022,dc=kr' -w Skill39 -b 'dc=wsc2022,dc=kr' '(&(objectClass=posixAccount)(|(uid=james)(uid=donald)))' | less
echo
read

echo -e '\e[32mOpenLDAP: Access Control\e[m'
echo "# ldapsearch -x -b 'dc=wsc2022,dc=kr'"
ldapsearch -x -b 'dc=wsc2022,dc=kr'
echo
read
