Write-Host "# === Sub Criterion: worker.wsc2024.fr ===`r`n" -ForeGroundColor Green

Write-Host "# Aspect - Domain member" -ForeGroundColor Green
echo "Get-ComputerInfo | select CsDomain"
Get-ComputerInfo | select CsDomain | oh
pause

Write-Host "# Aspect - Web: Redirection" -ForeGroundColor Green
echo "Launch Edge, then browse http://www.wsc2024.fr/`r`n"
cmd /c start msedge http://www.wsc2024.fr/
pause

Write-Host "# Aspect - E-Mail: Configured account" -ForeGroundColor Green
echo "Log in as `"mgr-001`". Launch Mail Application, then open account settings`r`n"
pause

Write-Host "# Aspect - E-Mail: Send  & receive mail" -ForeGroundColor Green
echo "Send mail to james@wsc2022.kr`r`n"
pause

Write-Host "# Aspect - GPO: First-Login animation" -ForeGroundColor Green
echo "Log in as a user of Competitors group. (com-001 to com-054)`r`n"
'com-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 55)
echo ""
pause
