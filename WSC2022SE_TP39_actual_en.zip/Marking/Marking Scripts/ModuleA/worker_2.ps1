Write-Host "# === Sub Criterion: worker.wsc2024.fr ===`r`n" -ForeGroundColor Green

Write-Host "# Aspect - Folder redirection" -ForeGroundColor Green
echo "Create test.txt file on the Desktop."
pause
echo "ls \\fr-file\redirected\`$env:USERNAME\Desktop\ | select Name"
ls \\fr-file\redirected\$env:USERNAME\Desktop\ | select Name | oh
pause

Write-Host "# Aspect - Home drive" -ForeGroundColor Green
echo "Get-PSDrive | where Name -EQ H"
Get-PSDrive | where Name -EQ H | oh
pause

Write-Host "# Aspect - File: FSRM" -ForeGroundColor Green
echo "echo test > H:\test.txt"
echo test > H:\test.txt
echo "echo test > H:\test.bat"
echo test > H:\test.bat

echo "`r`nfsutil file createnew H:\testfile.txt 100000000"
fsutil file createnew H:\testfile.txt 100000000
echo "`r`nrm H:\testfile.txt"
rm H:\testfile.txt
echo "fsutil file createnew H:\testfile.txt 200000000"
fsutil file createnew H:\testfile.txt 200000000
echo ""
pause

Write-Host "# Aspect - File: Resource shared folder" -ForeGroundColor Green
echo "runas /user:wsc2024\`$('com-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 55)) powershell"
runas /user:wsc2024\$('com-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 55)) powershell
echo "`r`nls \\fr-file\Resource"
echo "exit`r`n"
pause
echo "runas /user:wsc2024\`$('vis-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 22)) powershell"
runas /user:wsc2024\$('vis-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 22)) powershell
echo "`r`nls \\fr-file\Resource"
echo "exit`r`n"
pause

Write-Host "# Aspect - File: WSC shared folder" -ForeGroundColor Green
echo "runas /user:wsc2024\`$('com-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 55)) powershell"
runas /user:wsc2024\$('com-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 55)) powershell
echo "`r`ntry{echo `"test`" > '\\fr-file\wsc\Visitors\test.txt'}catch{`$_.Exception}"
echo "`$error.clear()"
echo "try{echo `"test`" > '\\fr-file\wsc\Competitors\test.txt'}catch{`$_.Exception}"
echo "if(!`$error){echo Success}"
echo "exit`r`n"
pause

Write-Host "# Aspect - File: Access-based enumeration" -ForeGroundColor Green
echo "runas /user:wsc2024\`$('com-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 55)) powershell"
runas /user:wsc2024\$('com-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 55)) powershell
echo "`r`nls \\fr-file\wsc\ | select Name"
echo "exit`r`n"
pause
echo "runas /user:wsc2024\`$('vis-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 22)) powershell"
runas /user:wsc2024\$('vis-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 22)) powershell
echo "`r`nls \\fr-file\wsc\ | select Name"
echo "exit`r`n"
pause

Write-Host "# Aspect - GPO: drive mapping" -ForeGroundColor Green
echo "Get-PSDrive | where Name -EQ G"
Get-PSDrive | where Name -EQ G | oh
echo "*Log in as a user of Managers group. (mgr-001 to mgr-026)`r`n"
'mgr-'+'{0:d3}' -f (Get-Random -Minimum 1 -Maximum 26)
echo ""
pause
