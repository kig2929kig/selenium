Write-Host "# === Sub Criterion: worker.wsc2024.fr ===`r`n" -ForeGroundColor Green

Write-Host "# Aspect - GPO: drive mapping" -ForeGroundColor Green
echo "Get-PSDrive | where Name -EQ G"
Get-PSDrive | where Name -EQ G | oh
pause

Write-Host "# Aspect - GPO: Auto certificate enrollment" -ForeGroundColor Green
echo "rm cert:\CurrentUser\My\*"
rm cert:\CurrentUser\My\*
echo "gpupdate /force"
gpupdate /force
echo "sleep 30"
sleep 30
echo "ls cert:\CurrentUser\My\|measure|select count"
ls cert:\CurrentUser\My\|measure|select count|oh
pause

Write-Host "# Aspect - ADFS: Authentication using LDAP" -ForeGroundColor Green
echo "Launch Edge(InPrivate window), then browse https://adfs.wsc2024.fr/adfs/ls/idpinitiatedsignon`r`n"
cmd /c start msedge https://adfs.wsc2024.fr/adfs/ls/idpinitiatedsignon -inprivate
pause

Write-Host "# Aspect - RDS: Publish app" -ForeGroundColor Green
echo "Launch IE, then browse https://rds.wsc2024.fr/RDWeb/, Launch WordPad RemoteApp via RD web`r`n"
& 'C:\Program Files\internet explorer\iexplore.exe' https://rds.wsc2024.fr/RDWeb/
pause

Write-Host "# Aspect - Web: Client authentication" -ForeGroundColor Green
echo "wget https://www.wsc2024.fr/managers/ -UseBasicParsing | select StatusCode"
wget https://www.wsc2024.fr/managers/ -UseBasicParsing | select StatusCode | oh
echo "wget https://www.wsc2024.fr/managers/ -UseBasicParsing -Certificate (Get-ChildItem Cert:\CurrentUser\My\*) | select StatusCode"
wget https://www.wsc2024.fr/managers/ -UseBasicParsing -Certificate (Get-ChildItem Cert:\CurrentUser\My\*) | select StatusCode | oh
pause

Write-Host "# Aspect - Web: ADFS authentication" -ForeGroundColor Green
echo "Launch Edge(InPrivate window), then browse https://www.wsc2022.kr/wsc2024/`r`n"
cmd /c start msedge https://www.wsc2022.kr/wsc2024/ -inprivate
pause

Write-Host "# Aspect - Web: ADFS authorization" -ForeGroundColor Green
echo "Launch Edge(InPrivate window), then browse https://www.wsc2022.kr/wsc2022/, then browse https://www.wsc2022.kr/wsc2024/`r`n"
cmd /c start msedge https://www.wsc2022.kr/wsc2022/ -inprivate
pause
