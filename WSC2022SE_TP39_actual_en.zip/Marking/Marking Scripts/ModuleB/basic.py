import netmiko, random, time

CML_USERNAME = 'admin'
CML_PASSWORD = 'Skill39##'
#CML_CONTROLLER = '192.168.100.224' #IP CML
CML_CONTROLLER = '10.22.0.240' #IP CML
ENABLE_SECRET = 'Skill39'
#LAB_NAME = '118d80' # LAB ID
LAB_NAME = 'Module_B'

def connect(host, command_set):
    while True:
        try:
            # open the Netmiko connection via the terminal server
    
            # (SSH to the controller connects to the terminal server)
            c = netmiko.ConnectHandler(device_type='terminal_server',
                        host=CML_CONTROLLER,
                        username=CML_USERNAME,
                        password=CML_PASSWORD,
                        secret=ENABLE_SECRET)
    
            # send CR, get a prompt on terminal server
            c.write_channel('\r')
    
            # open the connection to the console
            c.write_channel(f'open /{LAB_NAME}/{host}/0\r')
    
            # switch to Cisco IOS mode
            netmiko.redispatch(c, device_type='cisco_ios')

            # send command set to devices
            c.find_prompt()
            c.enable()
            result = c.send_config_set(command_set)
            print(result)
    
            break
        except:
            while True:
                value=input('Cannot connect to console of {}. If connection is failed over and over, please, consider manual assessment about this aspect. Retry?(y/n): '.format(host))
                if value == 'y' or value == 'n':
                    break
                else:
                    print('Invalid input! Please, try again.')

            if value == 'n':
                break

print('\n')
print('########## Hostname and DomainName ##########')
print('\n')
NODES = [ 'ASW1', 'ASW2', 'DSW1', 'DSW2', 'HQ1', 'HQ2', 'BR1', 'BR2', 'ISP' ]
LAB_NODE = random.choice(NODES)
command_set = [ 'do show ip domain' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## TimeZone ##########')
print('\n')
NODES = [ 'ASW1', 'ASW2', 'DSW1', 'DSW2', 'HQ1', 'HQ2', 'BR1', 'BR2', 'ISP' ]
LAB_NODE = random.choice(NODES)
command_set = [ 'do show run | include clock timezone' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## Privileged mode password ##########')
print('\n')
NODES = [ 'ASW1', 'ASW2', 'DSW1', 'DSW2', 'HQ1', 'HQ2', 'BR1', 'BR2', 'ISP' ]
LAN_NODE = random.choice(NODES)
command_set = [ 'do show run | include enable secret' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## IP addressing - ASW1 ##########')
print('\n')
LAB_NODE = 'ASW1'
command_set = [ 'do show ip interface brief | exclude unassigned', 'do show ipv6 interface brief | section Vlan' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## IP addressing - ASW2 ##########')
print('\n')
LAB_NODE = 'ASW2'
command_set = [ 'do show ip interface brief | exclude unassigned', 'do show ipv6 interface brief | section Vlan' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## IP addressing - DSW1 ##########')
print('\n')
LAB_NODE = 'DSW1'
command_set = [ 'do show ip interface brief | exclude unassigned', 'do show ipv6 interface brief | section Vlan' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## IP addressing - DSW2 ##########')
print('\n')
LAB_NODE = 'DSW2'
command_set = [ 'do show ip interface brief | exclude unassigned', 'do show ipv6 interface brief | section Vlan' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## IP addressing - HQ1 ##########')
print('\n')
LAB_NODE = 'HQ1'
command_set = [ 'do show ip interface brief | exclude unassigned' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## IP addressing - HQ2 ##########')
print('\n')
LAB_NODE = 'HQ2'
command_set = [ 'do show ip interface brief | exclude unassigned' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## IP addressing - BR1 ##########')
print('\n')
LAB_NODE = 'BR1'
command_set = [ 'do show ip interface brief | exclude unassigned' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## IP addressing - BR2 ##########')
print('\n')
LAB_NODE = 'BR2'
command_set = [ 'do show ip interface brief | exclude unassigned' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## IP addressing - ISP ##########')
print('\n')
LAB_NODE = 'ISP'
command_set = [ 'do show ip interface brief | exclude unassigned' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## IP addressing - FW1 ##########')
print('\n')
LAB_NODE = 'FW1'
command_set = [ 'show interface ip brief | exclude unassigned', 'show ipv6 interface brief inside' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Finish this Marking Section - Basic Configuration:")
