import netmiko, random, time

CML_USERNAME = 'admin'
CML_PASSWORD = 'Skill39##'
#CML_CONTROLLER = '192.168.100.224' #IP CML
CML_CONTROLLER = '10.22.0.240' #IP CML
ENABLE_SECRET = 'Skill39'
#LAB_NAME = '118d80' # LAB ID
LAB_NAME = 'Module_B'

def connect(host, command_set):
    while True:
        try:
            # open the Netmiko connection via the terminal server
    
            # (SSH to the controller connects to the terminal server)
            c = netmiko.ConnectHandler(device_type='terminal_server',
                        host=CML_CONTROLLER,
                        username=CML_USERNAME,
                        password=CML_PASSWORD,
                        secret=ENABLE_SECRET)
    
            # send CR, get a prompt on terminal server
            c.write_channel('\r')
    
            # open the connection to the console
            c.write_channel(f'open /{LAB_NAME}/{host}/0\r')
    
            # switch to Cisco IOS mode
            netmiko.redispatch(c, device_type='cisco_ios')

            # send command set to devices
            c.find_prompt()
            c.enable()
            result = c.send_config_set(command_set)
            print(result)
    
            break
        except:
            while True:
                value=input('Cannot connect to console of {}. If connection is failed over and over, please, consider manual assessment about this aspect. Retry?(y/n): '.format(host))
                if value == 'y' or value == 'n':
                    break
                else:
                    print('Invalid input! Please, try again.')

            if value == 'n':
                break

print('\n')
print('########## BGP - Neighborship ##########')
print('\n')
#NODES = [ 'n0', 'n3']  # Nodes ID
NODES = [ 'ISP', 'HQ1']
command_set = [ 'do show bgp nei | inc remote AS | BGP state' ]
for LAB_NODE in NODES:
    connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## BGP - Configuration (Judgment) ##########')
print('\n')
#LAB_NODE = 'n2' # Nodes ID
LAB_NODE = 'BR1'
command_set = [ 'do show ip route bgp' ]
connect(LAB_NODE, command_set)
print('\n')
#LAB_NODE = 'n2' # Nodes ID
LAB_NODE = 'ISP'
command_set = [ 'do show run | include password' ]
connect(LAB_NODE, command_set)
print('Check BGP protocol are securely configured with an additional feature (e.g. authentication between all neighbors)')
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## EIGRP - Routing Table ##########')
print('\n')
#LAB_NODE = 'n4' # Nodes ID
LAB_NODE = 'HQ2'
command_set = [ 'do show ip route eigrp 2022 | section 172.20', 'do show ip route eigrp 2022 | section 192.168.10.0', 'do show ip route eigrp 2022 | section 192.168.20.0', 'do show ip route eigrp 2022 | section 192.168.1.0/30' ]
connect(LAB_NODE, command_set)

print('\n')
#LAB_NODE = 'n3' # Nodes ID
LAB_NODE = 'HQ1'
command_set = [ 'do show ip route eigrp 2022 | section 192.168.2.0/30' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## EIGRP - Summarization ##########')
print('\n')
#NODES = [ 'n2', 'n1']  # Nodes ID
NODES = [ 'BR1', 'BR2']
command_set = [ 'do show ip route eigrp 2022 | section 192.168.0.0' ]
for LAB_NODE in NODES:
    connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## OSPFv3 - Authentication ##########')
print('\n')
#LAB_NODE = 'n3' # Nodes ID
#LAB_NODE = 'HQ1'
NODES = [ 'HQ1' , 'HQ2']
command_set = [ 'do show ipv6 ospf interface gig0/1 | section authentication', 'do show ipv6 ospf interface gig0/2 | section authentication' ]
for LAB_NODE in NODES:
    connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## OSPFv3 - No DR/BDR election ##########')
print('\n')
#NODES = [ 'n5', 'n6']  # Nodes ID
NODES = [ 'DSW1', 'DSW2']
command_set = [ 'do show ipv6 ospf neighbor | include Gi' ]
for LAB_NODE in NODES:
    connect(LAB_NODE, command_set)
temp=input("Press Enter to Next to Aspect:")

print('\n')
print('########## OSPFv3 - Routing Table and Multi-Area ##########')
print('\n')
#LAB_NODE = 'n0' # Nodes ID
LAB_NODE = 'ISP'
command_set = [ 'do show ipv6 route ospf | sec 2001:' ]
connect(LAB_NODE, command_set)

print('\n')
#LAB_NODE = 'n3' # Nodes ID
LAB_NODE = 'HQ1'
command_set = [ 'do show ipv6 ospf int br | sec 2022' ]
connect(LAB_NODE, command_set)

print('\n')
#LAB_NODE = 'n7' # Nodes ID
LAB_NODE = 'FW1'
command_set = [ 'show ipv6 ospf interface brief | inc 100' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## IPv6 Communication ##########')
print('\n')
print('From HQ-SRV:')
print('#ping 2001:624c:3201:100::1')
temp=input("Run the command in HQ-SRV manually and Press Enter to Next Aspect:")

print('\n')
print('########## Traffic balancing - between HQ and Internet ##########')
print('\n')
print('From HQ-SRV:')
print('#traceroute -n 8.8.8.8')
temp=input("Run the command in HQ-SRV manually and Press Enter to Next Aspect:")

print('\n')
print('########## Traffic balancing - between HQ and BRANCH ##########')
print('\n')
print('From BR-CLI1:')
print('>tracert -d 192.168.10.1')
temp=input("Run the command in BR-CLI1 manually and Press Enter to continue:")

print('\n')
#LAB_NODE = 'n7' # Nodes ID
LAB_NODE = 'HQ2'
command_set = [ 'int range gig0/1-2', 'shutdown' ]
connect(LAB_NODE, command_set)
temp=input("Please, wait for 15 sec... and then Press Enter to continue:")

print('\n')
print('From BR-CLI1:')
print('>tracert -d 192.168.10.1')
temp=input("Run the command in BR-CLI1 manually and Press Enter to continue:")

print('\n')
#LAB_NODE = 'n7' # Nodes ID
LAB_NODE = 'HQ2'
command_set = [ 'int range gig0/1-2', 'no shutdown' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Finish Marking Section - Routing:")
