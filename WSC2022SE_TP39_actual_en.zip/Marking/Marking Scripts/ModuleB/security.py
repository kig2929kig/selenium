import netmiko, random, time

CML_USERNAME = 'admin'
CML_PASSWORD = 'Skill39##'
#CML_CONTROLLER = '192.168.100.224' #IP CML
CML_CONTROLLER = '10.22.0.240' #IP CML
ENABLE_SECRET = 'Skill39'
#LAB_NAME = '118d80' # LAB ID
LAB_NAME = 'Module_B'

def connect(host, command_set):
    while True:
        try:
            # open the Netmiko connection via the terminal server
    
            # (SSH to the controller connects to the terminal server)
            c = netmiko.ConnectHandler(device_type='terminal_server',
                        host=CML_CONTROLLER,
                        username=CML_USERNAME,
                        password=CML_PASSWORD,
                        secret=ENABLE_SECRET)
    
            # send CR, get a prompt on terminal server
            c.write_channel('\r')
    
            # open the connection to the console
            c.write_channel(f'open /{LAB_NAME}/{host}/0\r')
    
            # switch to Cisco IOS mode
            netmiko.redispatch(c, device_type='cisco_ios')

            # send command set to devices
            c.find_prompt()
            c.enable()
            result = c.send_config_set(command_set)
            print(result)
    
            break
        except:
            while True:
                value=input('Cannot connect to console of {}. If connection is failed over and over, please, consider manual assessment about this aspect. Retry?(y/n): '.format(host))
                if value == 'y' or value == 'n':
                    break
                else:
                    print('Invalid input! Please, try again.')

            if value == 'n':
                break

print('\n')
print('########## Console Authentication ##########')
print('\n')
print('Choose one device from topology, run exit command from Privilege Mode, then login.')
print('Username: admin')
print('Password: Skill39')
temp=input("You have to check this manually, and then Press Enter to Next Aspect:")

print('\n')
print('########## SSHv2 - RADIUS Account ##########')
print('\n')
print('Test SSH access from HQ-CLI as the below. (Choose between HQ1 and HQ2.):')
print('>ssh user1@192.168.1.2')
print('Password: Skill39')
temp=input("You have to check this manually, and then Press Enter to Next Aspect:")

print('\n')
print('########## SSHv2 - Backup Method ##########')
print('\n')
print('From HQ-SRV, stop the freeradius service.')
temp=input("Press Enter to continue:")

print('\n')
print('Test SSH access from HQ-CLI as the below. (Choose between HQ1 and HQ2.):')
print('>ssh user1@192.168.1.2')
print('Password: Skill39')
temp=input("Press Enter to continue:")

print('\n')
print('Test SSH access from HQ-CLI as the below. (Choose between HQ1 and HQ2.):')
print('>ssh admin@192.168.1.2')
print('Password: Skill39')
temp=input("Press Enter to continue:")

print('\n')
print('From HQ-SRV, start the freeradius service.')
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## SSHv2 - Access-Class ##########')
print('\n')
print('Test SSH access from HQ-SRV as the below. (Choose between HQ1 and HQ2.):')
print('#ssh user1@192.168.1.2')
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## SSHv2 - User2 Policy ##########')
print('\n')
print('Test SSH access from HQ-CLI as the below. (Choose between HQ1 and HQ2.):')
print('>ssh user2@192.168.1.2')
print('Password: Skill39')
print('HQ1#show privilege')
temp=input("Press Enter to continue:")

print('\n')
print('From HQ-CLI:')
print('HQ1#conf t\nHQ1(config)#int lo 55\nHQ1(config-if)#shut\nHQ1(config-if)#no shut\nHQ1(config-if)#ip addr 55.55.55.55 255.255.255.255\nHQ1(config-if)#no ip addr')
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## Port-Security ##########')
print('\n')
#LAB_NODE = 'n9' # Nodes ID
LAB_NODE = 'ASW2'
command_set = [ 'do show port-security int gig0/0', 'do show errdisable recovery | include Timer interval', 'do show errdisable recovery | include psecure' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## DHCP Snooping ##########')
print('\n')
#LAB_NODE = 'n9' # Nodes ID
LAB_NODE = 'ASW2'
command_set = [ 'do show ip dhcp snooping binding' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Finish this Marking Section - Security:")
