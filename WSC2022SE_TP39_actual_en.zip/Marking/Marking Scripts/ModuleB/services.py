import netmiko, random, time

CML_USERNAME = 'admin'
CML_PASSWORD = 'Skill39##'
#CML_CONTROLLER = '192.168.100.224' #IP CML
CML_CONTROLLER = '10.22.0.240' #IP CML
ENABLE_SECRET = 'Skill39'
#LAB_NAME = '118d80' # LAB ID
LAB_NAME = 'Module_B'

def connect(host, command_set):
    while True:
        try:
            # open the Netmiko connection via the terminal server
    
            # (SSH to the controller connects to the terminal server)
            c = netmiko.ConnectHandler(device_type='terminal_server',
                        host=CML_CONTROLLER,
                        username=CML_USERNAME,
                        password=CML_PASSWORD,
                        secret=ENABLE_SECRET)
    
            # send CR, get a prompt on terminal server
            c.write_channel('\r')
    
            # open the connection to the console
            c.write_channel(f'open /{LAB_NAME}/{host}/0\r')
    
            # switch to Cisco IOS mode
            netmiko.redispatch(c, device_type='cisco_ios')

            # send command set to devices
            c.find_prompt()
            c.enable()
            result = c.send_config_set(command_set)
            print(result)
    
            break
        except:
            while True:
                value=input('Cannot connect to console of {}. If connection is failed over and over, please, consider manual assessment about this aspect. Retry?(y/n): '.format(host))
                if value == 'y' or value == 'n':
                    break
                else:
                    print('Invalid input! Please, try again.')

            if value == 'n':
                break

print('\n')
print('########## NAT - Dynamic NAT ##########')
print('\n')
print('From HQ-CLI:')
print('>ping 8.8.8.8')
temp=input("Run this command in HQ-CLI and then Press Enter:")

print('\n')
#LAB_NODE = 'n3' # Nodes ID
LAB_NODE = 'HQ1'
command_set = [ 'do show ip nat translations | include icmp' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## NAT - PAT ##########')
print('\n')
print('From BR-CLI1:')
print('#ping 8.8.8.8')
temp=input("Run this command in BR-CLI1 and then Press Enter:")

print('\n')
#LAB_NODE = 'n2' # Nodes ID
LAB_NODE = 'BR1'
command_set = [ 'do show ip nat translations | include icmp' ]
connect(LAB_NODE, command_set)

print('\n')
print('From BR-CLI2:')
print('#ping 8.8.8.8')
temp=input("Run this command in BR-CLI2 and then Press Enter:")

print('\n')
#LAB_NODE = 'n1' # Nodes ID
LAB_NODE = 'BR2'
command_set = [ 'do show ip nat translations | include icmp' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## NAT - Port-Forwarding ##########')
print('\n')
print('From REMOTE:')
print('>nslookup www.wsc2022.net')
print('>start http://www.wsc2022.net')
temp=input("Run this command in REMOTE and then Press Enter:")


print('\n')
print('########## DHCP ##########')
print('\n')
print('From BR-CLI1, BR-CLI2, HQ-CLI:')
print('>ipconfig /all')
temp=input("Run this command in BR-CLI1, BR-CLI2 and HQ-CLI and then Press Enter:")

print('\n')
print('########## HSRP ##########')
print('\n')
#LAB_NODE = 'n5' # Nodes ID
LAB_NODE = 'DSW1'
command_set = [ 'do show standby brief' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## SNMP - Configuration ##########')
print('\n')
#NODES = [ 'n3', 'n4']  # Nodes ID
NODES = [ 'HQ1', 'HQ2']
command_set = [ 'do show snmp contact', 'do show snmp location' ]
for LAB_NODE in NODES:
    connect(LAB_NODE, command_set)

print('\n')
#LAB_NODE = 'n7' # Nodes ID
LAB_NODE = 'FW1'
command_set = [ 'show run | include contact', 'show run | include location' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## Cacti Monitoring Page ##########')
print('\n')
print('From HQ-CLI:')
print('Access "http://192.168.10.1/cacti". -> Login as "admin" user.(Password: Skill39) -> Enter "Graphs". category.')
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## NTP ##########')
print('\n')
#NODES = [ 'n0', 'n1', 'n2', 'n3', 'n4', 'n5' 'n6', 'n8' ]
NODES = [ 'ASW1', 'ASW2', 'DSW1', 'DSW2', 'HQ1', 'HQ2', 'BR1', 'BR2' ]
LAB_NODE = random.choice(NODES)
command_set = [ 'do show ntp asso' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Finish this Marking Section - Services:")
