import netmiko, random, time

CML_USERNAME = 'admin'
CML_PASSWORD = 'Skill39##'
#CML_CONTROLLER = '192.168.100.224' #IP CML
CML_CONTROLLER = '10.22.0.240' #IP CML
ENABLE_SECRET = 'Skill39'
#LAB_NAME = '118d80' # LAB ID
LAB_NAME = 'Module_B'

def connect(host, command_set):
    while True:
        try:
            # open the Netmiko connection via the terminal server
    
            # (SSH to the controller connects to the terminal server)
            c = netmiko.ConnectHandler(device_type='terminal_server',
                        host=CML_CONTROLLER,
                        username=CML_USERNAME,
                        password=CML_PASSWORD,
                        secret=ENABLE_SECRET)
    
            # send CR, get a prompt on terminal server
            c.write_channel('\r')
    
            # open the connection to the console
            c.write_channel(f'open /{LAB_NAME}/{host}/0\r')
    
            # switch to Cisco IOS mode
            netmiko.redispatch(c, device_type='cisco_ios')

            # send command set to devices
            c.find_prompt()
            c.enable()
            result = c.send_config_set(command_set)
            print(result)
    
            break
        except:
            while True:
                value=input('Cannot connect to console of {}. If connection is failed over and over, please, consider manual assessment about this aspect. Retry?(y/n): '.format(host))
                if value == 'y' or value == 'n':
                    break
                else:
                    print('Invalid input! Please, try again.')

            if value == 'n':
                break

print('\n')
print('##########EtherChannel - Load-Balance Mode##########')
print('\n')
NODES = [ 'DSW1', 'DSW2', 'ASW1', 'ASW2' ]
command_set = [ 'do show etherchannel load-balance | section Configuration:' ]
for LAB_NODE in NODES:
    connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## EtherChannel - Group 1 Mode ON ##########')
print('\n')
LAB_NODE = 'DSW1'
command_set = [ 'do show etherchannel 1 detail | include On' ]
connect(LAB_NODE, command_set)

LAB_NODE = 'DSW2'
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## EtherChannel - Group 2 PAGP Protocol ##########')
print('\n')
LAB_NODE = 'DSW1'
command_set = [ 'do show etherchannel 2 detail | include Desirable' ]
connect(LAB_NODE, command_set)

print('\n')
LAB_NODE = 'ASW1'
command_set = [ 'do show etherchannel 2 detail | include Automatic' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## EtherChannel - Group 3 LACP Protocol ##########')
print('\n')
LAB_NODE = 'DSW2'
command_set = [ 'do show etherchannel 3 detail | include Active' ]
connect(LAB_NODE, command_set)

print('\n')
LAB_NODE = 'ASW2'
command_set = [ 'do show etherchannel 3 detail | include Passive' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## Trunk ports and Pruning ##########')
print('\n')
LAB_NODE = 'DSW1'
command_set = [ 'do show int trunk' ]
connect(LAB_NODE, command_set)

print('\n')
LAB_NODE = 'DSW2'
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## STP - VLANs and Root bridge ##########')
print('\n')
LAB_NODE = 'DSW1'
command_set = [ 'do show vlan brief | section active', 'do show spanning-tree vlan 10 | include root' ]
connect(LAB_NODE, command_set)

print('\n')
LAB_NODE = 'DSW2'
command_set = [ 'do show spanning-tree vlan 20 | include root' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## STP - Traffics of HQ-CLI ##########')
print('\n')
LAB_NODE = 'DSW2'
command_set = [ 'do show mac address-table | include Po3' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## VTP - Configuration ##########')
print('\n')
LAB_NODE = 'DSW1'
command_set = [ 'do show vtp status | include running | Server' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## PortFast ##########')
print('\n')
LAB_NODE = 'ASW1'
command_set = [ 'do show spanning-tree int gig0/0 portfast' ]
connect(LAB_NODE, command_set)

print('\n')
LAB_NODE = 'ASW2'
command_set = [ 'do show spanning-tree int gig0/0 portfast' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## STP Protocol ##########')
print('\n')
LAB_NODE = 'DSW1'
command_set = [ 'do show spanning-tree | include protocol' ]
connect(LAB_NODE, command_set)

print('\n')
LAB_NODE = 'DSW2'
command_set = [ 'do show spanning-tree | include protocol' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Finish this Marking Section - Switching:")

