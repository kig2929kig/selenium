import netmiko, random, time

CML_USERNAME = 'admin'
CML_PASSWORD = 'Skill39##'
#CML_CONTROLLER = '192.168.100.224' #IP CML
CML_CONTROLLER = '10.22.0.240' #IP CML
ENABLE_SECRET = 'Skill39'
#LAB_NAME = '118d80' # LAB ID
LAB_NAME = 'Module_B'

def connect(host, command_set):
    while True:
        try:
            # open the Netmiko connection via the terminal server
    
            # (SSH to the controller connects to the terminal server)
            c = netmiko.ConnectHandler(device_type='terminal_server',
                        host=CML_CONTROLLER,
                        username=CML_USERNAME,
                        password=CML_PASSWORD,
                        secret=ENABLE_SECRET)
    
            # send CR, get a prompt on terminal server
            c.write_channel('\r')
    
            # open the connection to the console
            c.write_channel(f'open /{LAB_NAME}/{host}/0\r')
    
            # switch to Cisco IOS mode
            netmiko.redispatch(c, device_type='cisco_ios')

            # send command set to devices
            c.find_prompt()
            c.enable()
            result = c.send_config_set(command_set)
            print(result)
    
            break
        except:
            while True:
                value=input('Cannot connect to console of {}. If connection is failed over and over, please, consider manual assessment about this aspect. Retry?(y/n): '.format(host))
                if value == 'y' or value == 'n':
                    break
                else:
                    print('Invalid input! Please, try again.')

            if value == 'n':
                break

print('\n')
print('########## PPPoE ##########')
print('\n')
NODES = [ 'ISP', 'BR1' ]
command_set = [ 'do show ppp all' , 'do show run | sec ppp' ]
for LAB_NODE in NODES:
    connect(LAB_NODE, command_set)
print('\n')
temp=input("You have to check in HQ-SRV, stop freeradius and run 'freeradius -X', then run 'clear ppp all' command in BR1 :")
temp=input("Wait 30 sg and authentication should appers on HQ-SRV, Ctrl C, in the Server, and then Press Enter here to Next Aspect:")

print('\n')
print('########## Tunnels between HQs and BRs - Implementation ##########')
print('\n')
print('Check tunnel configuration from HQs and BRs routers.')
NODES = [ 'BR1', 'BR2', 'HQ1' ]
command_set = [ 'do show run | sec Tun' , 'do show dmvpn | inc UP' ]
for LAB_NODE in NODES:
    connect(LAB_NODE, command_set)
print('\n')
temp=input("Finally, from BR-CLI1 run the command ping 172.20.20.254, and then Press Enter to Next Aspect:")

print('\n')
print('########## Tunnels between HQs and BRs - Encryption ##########')
print('\n')
LAB_NODE = 'HQ1'
command_set = [ 'do show crypto ikev2 sa | include 3.3.3.3', 'do show crypto ikev2 sa | include 4.4.4.4' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## Tunnels between HQs and BRs - Communication ##########')
print('\n')
print('From BR-CLI1 and BR-CLI2:')
print('>ping 192.168.10.1')
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## Tunnel between HQ1 and FW1 - Encryption ##########')
print('\n')
LAB_NODE = 'HQ1'
command_set = [ 'do show crypto ikev2 sa | include 98.76.5.1' ]
connect(LAB_NODE, command_set)
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## Tunnel between HQ1 and FW1 - Communication ##########')
print('\n')
print('From HQ-CLI, BR-CLI1 and BR-CLI2:')
print('>ping 192.168.100.1')
temp=input("Press Enter to Next Aspect:")

print('\n')
print('########## Remote Access VPN ##########')
print('\n')
print('From Remote:')
print('Firts Verify if AnyConnect Program is in REMOTE, then Open anyconnect client program, and connect VPN.')
print('1) FQDN: vpn.wsc2022.net')
print('2) username: vpnuser')
print('3) password: Skill39')
print('Finally, verify in ASA the configurarion') 
print('The Second Options, is to verify by Windows VPN app, and try connect.')
temp=input("Press Enter to continue:")

print('\n')
print('From Remote:')
print('>nslookup www.wsc2022.net')
temp=input("Press Enter to continue:")

print('\n')
print('From Remote:')
print('>ping 192.168.10.1')
temp=input("Press Enter to continue:")

print('\n')
print('########### Configuration Backup ###########')
temp=input("Verify in HQ-SRV in the location of TP, and check that appears the new file with name and time, after run the command write in HQ1 and BR2, finally, Press Enter to Finish All Marking Scheme:")
