#!/bin/sh
# Create snapshot for HOST VM
for vmId in $(vim-cmd vmsvc/getallvms | grep -v Vmid | awk '{ print $1 }')
do
    vim-cmd vmsvc/snapshot.create $vmId C2Marking C2Marking
done

# Revert the LIN1-5 and WIN1-5
for vmId in $(vim-cmd vmsvc/getallvms | grep -e LIN -e WIN | grep -v DEV | awk '{ print $1 }')
do
    vim-cmd vmsvc/snapshot.revert $vmId $(vim-cmd vmsvc/snapshot.get $vmId | grep -A 2 Rollback | grep Id | awk '{ print $4 }') 0
done

# Add CDROM
for vmName in $(vim-cmd vmsvc/getallvms | grep -e LIN | grep -v DEV | awk '{ print $2 }')
do
    cat >> /vmfs/volumes/Datastore/$vmName/$vmName.vmx <<EOF
ide0:1.startConnected = "TRUE"
ide0:1.deviceType = "atapi-cdrom"
ide0:1.fileName = "emptyBackingString"
ide0:1.present = "TRUE"
ide1:0.startConnected = "TRUE"
ide1:0.deviceType = "atapi-cdrom"
ide1:0.fileName = "emptyBackingString"
ide1:0.present = "TRUE"
ide1:1.startConnected = "TRUE"
ide1:1.deviceType = "atapi-cdrom"
ide1:1.fileName = "emptyBackingString"
ide1:1.present = "TRUE"
EOF
done

# Reload vmx config and power on VMs
for vmId in $(vim-cmd vmsvc/getallvms | grep -e LIN -e WIN | grep -v DEV | awk '{ print $1 }')
do
    vim-cmd vmsvc/reload $vmId    
    vim-cmd vmsvc/power.on $vmId # power on VM
done
